fx_version 'cerulean'
games { 'gta5' }

client_script 'client.lua'

author 'Jarvis Development'
description 'Custom fivem rich presence, customise to your liking!'
version '1.0.0'